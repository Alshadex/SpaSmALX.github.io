package ShapeManipulators;

import ca.utoronto.utm.Factory.Point;
import ca.utoronto.utm.Factory.Squiggle;
import ca.utoronto.utm.Factory.ShapeModifiers;
import ca.utoronto.utm.drawableShapes.DrawableSquiggle;
import ca.utoronto.utm.paint.SelectionToolsPanel;
import ca.utoronto.utm.paint.View;
import javafx.scene.input.MouseEvent;

/**
 * The strategy for updating the squiggle that was last added
 * @author samjn
 *
 */
public class SquiggleStrategy implements ShapeManipulatorStrategy{

	/**
	 * The View, the DrawableSquiggle that the strategy will update and the current point.
	 */
	private View view;
	private DrawableSquiggle squiggle;
	private Point point;
	
	/**
     * Creates a strategy for updating the squiggle object that was last added to PaintModels commands
     * @param view The main View of the project
     */
	public SquiggleStrategy(View view) {
		this.view = view;
		this.point = null;
		this.squiggle = (DrawableSquiggle) this.view.getPaintModel().getLastCommand();
	}
	
	/**
	 * Updates the Squiggle when the mouse is pressed. Sets the color and thickness; creates a new Squiggle object and
	 * adds it to the commands
	 */
	@Override
	public void mousePressed(MouseEvent e) {
		this.squiggle = new DrawableSquiggle(new Squiggle(), new ShapeModifiers());
		this.squiggle.getStyle().setColor(this.view.getSelectionToolsPanel().getCurrentColor());
		this.squiggle.getStyle().setThickness(this.view.getSelectionToolsPanel().getThickness());
		this.view.getPaintModel().addCommand(this.squiggle,this.view.getPaintPanel().getGraphicsContext());
	}

	/**
	 * Updates the Squiggle when the mouse is dragged. Adds a point at each mouse position and updates the squiggle.
	 */
	@Override
	public void mouseDragged(MouseEvent e) {
		this.point = new Point((int)e.getX(),(int) e.getY());
		this.squiggle.addPoint(this.point);
		this.view.getPaintModel().updateCommand(this.squiggle, this.view.getPaintPanel().getGraphicsContext());
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
