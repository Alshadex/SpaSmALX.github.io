package ShapeManipulators;

import ca.utoronto.utm.Factory.Point;
import ca.utoronto.utm.Factory.Rectangle;
import ca.utoronto.utm.drawableShapes.DrawableRectangle;
import ca.utoronto.utm.paint.View;
import javafx.scene.input.MouseEvent;

/**
 * The strategy used to update the new DrawableRectangle
 * @author geniusName
 *
 */
public class RectangleStrategy implements ShapeManipulatorStrategy{

	/**
	 * The DrawableRectangle that will be updated and the main View of the project
	 */
	private View view;
	private DrawableRectangle rectangle;
	
	/**
	 * Creates a new strategy that will update the DrawableRectangle command that was last added.
	 * @param view The projects main View
	 */
	public RectangleStrategy (View view) {
		this.view = view;
		this.rectangle = (DrawableRectangle)view.getPaintModel().getLastCommand();
	}
	
	/**
	 * Updates the rectangle when the mouse is pressed. Sets the color and thickness depending on the options selected
	 */
	@Override
	public void mousePressed(MouseEvent e) {
		Point start = new Point((int)e.getX(), (int)e.getY());
		this.rectangle.getStyle().setColor(this.view.getSelectionToolsPanel().getCurrentColor());
		this.rectangle.getStyle().setThickness(this.view.getSelectionToolsPanel().getThickness());
		this.rectangle.getStyle().setSolid(this.view.getSelectionToolsPanel().isSolid());
		this.rectangle.setStartingPoint(start);
	}

	/**
	 * Updates the rectangle when the mouse is dragged. Sets the width and the height of the rectangle 
	 * to the mouse position.
	 */
	@Override
	public void mouseDragged(MouseEvent e) {
		int width = (int) e.getX() - this.rectangle.getStartingPoint().getX();
		int height = (int) e.getY() - this.rectangle.getStartingPoint().getY();
		this.rectangle.setWidth(width);
		this.rectangle.setHeight(height);
		this.view.getPaintModel().updateCommand(this.rectangle, this.view.getPaintPanel().getGraphicsContext());
	}

	/**
	 * Makes a new DrawableRectangle and adds it to the PaintModels' commands when the mouse is released.
	 */
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		this.rectangle = new DrawableRectangle(new Rectangle(), this.rectangle.getStyle());
		this.view.getPaintModel().addCommand(this.rectangle, this.view.getPaintPanel().getGraphicsContext());
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}
