package ShapeManipulators;

import ca.utoronto.utm.Factory.Point;
import ca.utoronto.utm.Factory.Rectangle;
import ca.utoronto.utm.Factory.Square;
import ca.utoronto.utm.drawableShapes.DrawableRectangle;
import ca.utoronto.utm.paint.View;
import javafx.scene.input.MouseEvent;

/**
 * The strategy used to update the new Square added
 * @author samjn
 *
 */
public class SquareStrategy implements ShapeManipulatorStrategy{

	/**
	 * The Square, which is a DrawableRectangle, that will be updated and the main project View
	 */
	private View view;
	private DrawableRectangle square;
	
	/**
	 * Creates a new strategy that will update the Square command that was last added.
	 * @param view The main View of the project
	 */
	public SquareStrategy (View view) {
		this.view = view;
		this.square = (DrawableRectangle) view.getPaintModel().getLastCommand();
	}
	
	/**
	 * Updates the square when the mouse is pressed. Sets the color, thickness, solid state and creates the starting point
	 * of the square.
	 */
	@Override
	public void mousePressed(MouseEvent e) {
		Point start = new Point((int)e.getX(), (int)e.getY());
		this.square.getStyle().setColor(this.view.getSelectionToolsPanel().getCurrentColor());
		this.square.getStyle().setThickness(this.view.getSelectionToolsPanel().getThickness());
		this.square.getStyle().setSolid(this.view.getSelectionToolsPanel().isSolid());
		this.square.setStartingPoint(start);
	}

	/**
	 * Updates the square when the mouse is dragged. Sets the width and the height of the square using the mouse position.
	 */
	@Override
	public void mouseDragged(MouseEvent e) {
		int width = (int) e.getX() - this.square.getStartingPoint().getX();
		int height = (int) e.getY() - this.square.getStartingPoint().getY();
		if(width >= 0 && height >= 0) {
			if(width > height){
				this.square.setWidth(width);
				this.square.setHeight(width);
			} else {
				this.square.setWidth(height);
				this.square.setHeight(height);
			}
		}else if(width < 0 && height >= 0) {
			if(-width > height){
				this.square.setWidth(width);
				this.square.setHeight(-width);
			} else {
				this.square.setWidth(-height);
				this.square.setHeight(height);
			}
		} else if(width >= 0 && height < 0) {
			if(width > -height){
				this.square.setWidth(width);
				this.square.setHeight(-width);
			} else {
				this.square.setWidth(-height);
				this.square.setHeight(height);
			}
		} else {
			if(-width > -height){
				this.square.setWidth(width);
				this.square.setHeight(width);
			} else {
				this.square.setWidth(height);
				this.square.setHeight(height);
			}
		}
		this.view.getPaintModel().updateCommand(this.square, this.view.getPaintPanel().getGraphicsContext());
	}

	/**
	 * Creates a new rectangle and adds it to the PaintModel's commands when the mouse is released.
	 */
	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		this.square = new DrawableRectangle(new Square(), this.square.getStyle());
		this.view.getPaintModel().addCommand(this.square, this.view.getPaintPanel().getGraphicsContext());
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


}
