package ShapeManipulators;

import ca.utoronto.utm.Factory.Circle;
import ca.utoronto.utm.Factory.Point;
import ca.utoronto.utm.Factory.ShapeModifiers;
import ca.utoronto.utm.drawableShapes.DrawableCircle;
import ca.utoronto.utm.paint.View;
import javafx.scene.input.MouseEvent;

/**
 * The strategy used to update the new circle.
 * 
 * @author geniusName
 *
 */
public class CircleStrategy implements ShapeManipulatorStrategy{
	
	/**
	 * The DrawableCircle to be updated and the main View
	 */
	private DrawableCircle circle;
	private View view;
	
	/**
	 * Creates a new strategy to update the DrawableCircle command that was last 
	 * added to the model.
	 * @param view the main view of the project
	 */
	public CircleStrategy(View view) {
		this.view = view;
		this.circle = (DrawableCircle) view.getPaintModel().getLastCommand();
	}

	/**
	 * Updates the style and attributes of the circle when the mouse is pressed
	 */
	@Override
	public void mousePressed(MouseEvent e) {
		Point center = new Point((int)e.getX(), (int)e.getY());
		this.circle.setCentre(center);
		this.circle.getStyle().setColor(this.view.getSelectionToolsPanel().getCurrentColor());
		this.circle.getStyle().setThickness(this.view.getSelectionToolsPanel().getThickness());
		this.circle.getStyle().setSolid(this.view.getSelectionToolsPanel().isSolid());
		this.view.getPaintModel().updateCommand(this.circle, this.view.getPaintPanel().getGraphicsContext());
	}

	/**
	 * Updates the style and attributes of the circle when the mouse is dragged
	 */
	@Override
	public void mouseDragged(MouseEvent e) {
		int xDistance = (int) Math.pow((int) this.circle.getCentre().getX() - e.getX(), 2);
		int yDistance = (int) Math.pow((int) this.circle.getCentre().getY() - e.getY(), 2);
		int radius = (int) Math.abs(Math.sqrt( xDistance + yDistance));
		this.circle.setRadius(radius);	
		this.view.getPaintModel().updateCommand(this.circle, this.view.getPaintPanel().getGraphicsContext());
	}

	/**
	 * Creates a new DrawableCircle and adds it to the PaintModel commands 
	 * when the mouse is released.
	 */
	@Override
	public void mouseReleased(MouseEvent e) {
		this.circle = new DrawableCircle(new Circle(), new ShapeModifiers());
		this.view.getPaintModel().addCommand(this.circle, this.view.getPaintPanel().getGraphicsContext());
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
}
