package ShapeManipulators;

import javafx.scene.input.MouseEvent;

/**
 * The interface for the strategies
 * @author geniusName
 *
 */
public interface ShapeManipulatorStrategy {

	/**
	 * The methods that update the shapes depending on the MouseEvent
	 * @param e The mouse event from the PaintPanel
	 */

	public void mousePressed(MouseEvent e);
	public void mouseDragged(MouseEvent e);
	public void mouseReleased(MouseEvent e);
	public void mouseClicked(MouseEvent e);
}
