package ShapeManipulators;

import ca.utoronto.utm.Factory.Point;
import ca.utoronto.utm.Factory.Polyline;
import ca.utoronto.utm.Factory.ShapeModifiers;
import ca.utoronto.utm.drawableShapes.DrawablePolyline;
import ca.utoronto.utm.paint.View;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.MouseButton;

/**
 * The strategy used to update the new Polyline
 * @author geniusName
 *
 */
public class PolylineStrategy implements ShapeManipulatorStrategy{
	/**
	 * The Polyline we will be updating and the two points that keep
	 * track of where to start and end each Polyline segment
	 */
	private View view;
	private DrawablePolyline polyline;
	private Point startingPoint;
	private Point endingPoint;
	
	/**
	 * Creates a new strategy for updating the DrawablePolyline command that
	 * was last added to the PaintModel. Sets the start and end point of the 
	 * strategy to null.
	 * @param view The projects main view
	 */
	public PolylineStrategy(View view) {
		this.view = view;
		this.startingPoint = null;
		this.endingPoint = null;
		this.polyline = (DrawablePolyline) this.view.getPaintModel().getLastCommand();
	}
	
	/**
	 * Updates the Polyline when the mouse is pressed. Updates the color, thickness and adds two points to make a segment of the 
	 * Polyline
	 */
	@Override
	public void mousePressed(MouseEvent e) {
		if (this.view.getPaintModel().getLastCommand().isEmpty()) {
			this.polyline.getStyle().setColor(this.view.getSelectionToolsPanel().getCurrentColor());
			this.polyline.getStyle().setThickness(this.view.getSelectionToolsPanel().getThickness());
			this.startingPoint = new Point((int)e.getX(),(int) e.getY());
			this.endingPoint= new Point((int) e.getX(), (int) e.getY());
			this.polyline.addPoint(this.startingPoint);
			this.polyline.addPoint(this.endingPoint);
		} else {
			this.endingPoint = new Point((int)e.getX(), (int)e.getY());
			this.polyline.getStyle().setColor(this.view.getSelectionToolsPanel().getCurrentColor());
			this.polyline.getStyle().setThickness(this.view.getSelectionToolsPanel().getThickness());
			this.polyline.addPoint(this.endingPoint);
			this.view.getPaintModel().updateCommand(this.polyline, this.view.getPaintPanel().getGraphicsContext());
		}
	}

	/**
	 * Updates the Polyline when the mouse is dragged. Setting the x and y of the end point of the current Polyline section.
	 */
	@Override
	public void mouseDragged(MouseEvent e) {
		this.endingPoint.setX((int) e.getX()); 
		this.endingPoint.setY((int) e.getY());
		this.view.getPaintModel().updateCommand(this.polyline, this.view.getPaintPanel().getGraphicsContext());
	}
	

	/**
	 * Adds a point to the Polyline in the PaintModel's commands when the mouse is released.
	 */
	@Override
	public void mouseReleased(MouseEvent e) {
		this.endingPoint.setX((int) e.getX()); 
		this.endingPoint.setY((int) e.getY());
		this.polyline.deleteLast();
		this.polyline.addPoint(this.endingPoint);
		this.view.getPaintModel().updateCommand(this.polyline, this.view.getPaintPanel().getGraphicsContext());
		
	}

	/**
	 * Finishes the current Polyline and makes a new Polyline when the secondary mouse button is pressed on the PaintPanel.
	 * Adds the new Polyline to the PaintModel commands.
	 */
	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getButton() == MouseButton.SECONDARY) {
			this.polyline = new DrawablePolyline(new Polyline(), new ShapeModifiers());
			this.view.getPaintModel().addCommand(this.polyline,this.view.getPaintPanel().getGraphicsContext());
		}
	}

}
