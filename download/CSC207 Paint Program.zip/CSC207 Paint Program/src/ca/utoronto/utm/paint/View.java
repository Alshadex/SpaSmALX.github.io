package ca.utoronto.utm.paint;

import java.net.URL;

import ShapeManipulators.ShapeManipulatorStrategy;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class View implements EventHandler<ActionEvent> {

	private PaintModel model;
	private PaintPanel paintPanel;
	private ShapeChooserPanel shapeChooserPanel;
	private SelectionToolsPanel selectionToolsPanel;
	private ShapeManipulatorStrategy strategy;

	public View(PaintModel model, Stage stage) {

		this.model = model;
		initUI(stage);
	}

	private void initUI(Stage stage) {
		
		this.shapeChooserPanel = new ShapeChooserPanel(this);
		this.paintPanel = new PaintPanel(this.model, this);
		this.selectionToolsPanel = new SelectionToolsPanel(this);

		VBox tools = new VBox();
		tools.getChildren().addAll(shapeChooserPanel, selectionToolsPanel);
		tools.setSpacing(5);

		BorderPane root = new BorderPane();
		root.setTop(createMenuBar());
		root.setCenter(this.paintPanel);
		root.setLeft(tools);

		Scene scene = new Scene(root);
		stage.setScene(scene);
		URL url = this.getClass().getResource("styles.css");
		if (url == null) {
			System.out.print("not found");
		}
		scene.getStylesheets().add(url.toExternalForm());
		stage.setTitle("Paint");
		stage.show();
	}

	public PaintPanel getPaintPanel() {
		return paintPanel;
	}

	public ShapeChooserPanel getShapeChooserPanel() {
		return shapeChooserPanel;
	}
	
	public SelectionToolsPanel getSelectionToolsPanel () {
		return selectionToolsPanel;
	}
	
	public PaintModel getPaintModel() {
		return model;
	}

	public void setStrategy(ShapeManipulatorStrategy strategy) {
		this.strategy = strategy;
	}
	
	public ShapeManipulatorStrategy getStrategy() {
		return this.strategy;
	}
	
	private MenuBar createMenuBar() {

		MenuBar menuBar = new MenuBar();
		Menu menu;
		MenuItem menuItem;


		menu = new Menu("File");

		menuItem = new MenuItem("New");
		menuItem.setOnAction(this);
		menu.getItems().add(menuItem);

		menuItem = new MenuItem("Open");
		menuItem.setOnAction(this);
		menu.getItems().add(menuItem);

		menuItem = new MenuItem("Save");
		menuItem.setOnAction(this);
		menu.getItems().add(menuItem);

		menu.getItems().add(new SeparatorMenuItem());

		menuItem = new MenuItem("Exit");
		menuItem.setOnAction(this);
		menu.getItems().add(menuItem);

		menuBar.getMenus().add(menu);

		// Another menu for Edit

		menu = new Menu("Edit");
		
		menuItem = new MenuItem("Clear");
		menuItem.setOnAction(this);
		menu.getItems().add(menuItem);
		
		menu.getItems().add(new SeparatorMenuItem());
		
		menuItem = new MenuItem("Cut");
		menuItem.setOnAction(this);
		menu.getItems().add(menuItem);

		menuItem = new MenuItem("Copy");
		menuItem.setOnAction(this);
		menu.getItems().add(menuItem);

		menuItem = new MenuItem("Paste");
		menuItem.setOnAction(this);
		menu.getItems().add(menuItem);

		menu.getItems().add(new SeparatorMenuItem());

		menuItem = new MenuItem("Undo");
		menuItem.setOnAction(this);
		menu.getItems().add(menuItem);

		menuItem = new MenuItem("Redo");
		menuItem.setOnAction(this);
		menu.getItems().add(menuItem);

		menuBar.getMenus().add(menu);

		return menuBar;
	}

	@Override
	public void handle(ActionEvent event) {
		if(((MenuItem)event.getSource()).getText() == "Undo") {
			this.getPaintModel().undo();
		} else if(((MenuItem)event.getSource()).getText() == "Redo") {
			this.getPaintModel().redo();
		} else if(((MenuItem)event.getSource()).getText() == "Clear") {
			this.getPaintModel().startOver();
		}
	}
}
