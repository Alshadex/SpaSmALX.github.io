package ca.utoronto.utm.paint;

import java.util.ArrayList;
import java.util.Observable;

import ca.utoronto.utm.drawableShapes.DrawablePolyline;
import ca.utoronto.utm.drawableShapes.DrawableSquiggle;
import ca.utoronto.utm.drawableShapes.DrawingCommand;
import javafx.scene.canvas.GraphicsContext;

public class PaintModel extends Observable {

	private ArrayList<DrawingCommand> commands = new ArrayList<DrawingCommand>();
	private ArrayList<DrawingCommand> undos = new ArrayList<DrawingCommand>();
	
	public void addCommand(DrawingCommand command, GraphicsContext g) {
		if(!this.commands.contains(command)) {
			this.commands.add(command);
			System.out.println(this.commands);
		}
	}
	
	public ArrayList<DrawingCommand> getCommands(){
		return this.commands;
	}
	
	public void execute(GraphicsContext g) {
		for(DrawingCommand command: this.commands) {
			if(!command.isEmpty()) {
				command.execute(g);
			}
		}
	}
	
	public void updateCommand(DrawingCommand command, GraphicsContext g) {
		if(this.commands.get(this.commands.size() - 1).equals(command)){
			this.commands.remove(this.commands.size() - 1);
			this.commands.add(command);
			System.out.println(this.commands);
			command.execute(g);
			this.setChanged();
			this.notifyObservers();
		}
	}
	
	public void undo() {
		if(!(this.commands.size() <= 1)) {
			if (this.commands.get(this.commands.size() - 1) instanceof DrawablePolyline ||
					this.commands.get(this.commands.size() - 1) instanceof DrawableSquiggle) {
				this.undos.add(this.commands.remove(this.commands.size() - 1));
			} else {
				this.undos.add(this.commands.remove(this.commands.size() - 2));
			}
			this.setChanged();
			this.notifyObservers();
		}
	}
	
	public void redo() {
		if(this.undos.size() != 0) {
			this.commands.add(this.commands.size() - 1, this.undos.remove(this.undos.size() - 1));
			this.setChanged();
			this.notifyObservers();
		}
	}
	
	public void startOver() {
		while(this.commands.size() != 1) {
			this.commands.remove(0);
		}
		this.setChanged();
		this.notifyObservers();
	}
	
	public DrawingCommand getLastCommand(){
		return this.commands.get(this.commands.size()-1);
	}
	
	public boolean isEmpty() {
		return this.commands.size() == 0;
	}
	
}
