package ca.utoronto.utm.paint;

import javax.swing.ButtonGroup;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.Slider;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Border;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;

public class SelectionToolsPanel extends GridPane implements EventHandler<MouseEvent> {

	//Instance Variables
	private int row = 0;
	private String currentColor = "WHITE";
	
	private View view;
	private Label thicknessLabel = new Label("Set thickness");
	private Label currentThickness = new Label("Thickness: 0");
	private Slider thicknessSlider = new Slider();
	private Label labelStyle = new Label("Style");
	private boolean style;
	private RadioButton outlineButton;
	private RadioButton solidButton;
	private double thickness;
	
	public SelectionToolsPanel(View view) {
		this.view = view;
		this.setAlignment(Pos.TOP_CENTER);
		this.thickness = 1.0;
		
		//Sets the properties for the slider
		thicknessLabel.setUnderline(true);
		
		thicknessSlider.setMin(1);
		thicknessSlider.setMax(100);
		thicknessSlider.setMinorTickCount(1);
		thicknessSlider.setShowTickMarks(true);
		thicknessSlider.setSnapToTicks(true);
		thicknessSlider.setMaxWidth(100);
		thicknessSlider.setOnMouseClicked(this);
        thicknessSlider.getValue();
		thicknessSlider.setMinWidth(150);
		thicknessSlider.getStyleClass().add("slide");
		
		
		
		//Sets up the grid for the color buttons
		String[] colors = {"BLACK", "WHITE", "RED", "ORANGE", "YELLOW", "GREEN", "BLUE", "VIOLET"};
		GridPane colorSelection = new GridPane();
		colorSelection.getStyleClass().addAll("colorSelection", "background");
		colorSelection.setAlignment(Pos.CENTER);
		colorSelection.setMinWidth(100);
		colorSelection.setHgap(20);
		colorSelection.setVgap(10);
		int i = 0;
		int j = 0;
		//Adds The buttons to the grid
		ToggleGroup colorsGroup = new ToggleGroup();
		for (String color: colors) {
			CustomButton col = new CustomButton(color, colorsGroup);
			String style = "-fx-background-color: " + color + ";";
			col.setMinWidth(40);
			col.setStyle(style);
			col.setOnMouseClicked(this);
			colorSelection.add(col, i, j);
			if (i == 1) {
				i = 0;
				j++;
			} else {
				i++;
			}
		}
		
		GridPane FillStyleSelectorGrid = new GridPane();
		FillStyleSelectorGrid.getStyleClass().add("background");
		FillStyleSelectorGrid.setAlignment(Pos.CENTER);
		FillStyleSelectorGrid.setMinWidth(50);
		FillStyleSelectorGrid.setHgap(20);
		FillStyleSelectorGrid.setVgap(10);
		//FillStyleSelectorGrid.setPadding(new Insets(10,5,10,5));
		ToggleGroup styleGroup = new ToggleGroup();
		this.outlineButton = new RadioButton("Outline");
		this.outlineButton.setToggleGroup(styleGroup);
		this.outlineButton.getStyleClass().add("fillOptions");
		this.outlineButton.setSelected(true);
		GridPane.setConstraints(this.outlineButton, 0,0);
		this.outlineButton.setMinWidth(40);
		this.outlineButton.setOnMouseClicked(this);
		
		this.solidButton = new RadioButton("Solid");
		this.solidButton.setToggleGroup(styleGroup);
		this.solidButton.getStyleClass().add("fillOptions");
		GridPane.setConstraints(this.solidButton, 1, 0);
		this.solidButton.setMinWidth(40);
		this.solidButton.setOnMouseClicked(this);
		
		FillStyleSelectorGrid.add(outlineButton, 0, 0);
		FillStyleSelectorGrid.add(this.solidButton, 0, 1);
		
		//Adds the elements to the view
		VBox thicknessTools = new VBox();
		thicknessTools.setAlignment(Pos.TOP_CENTER);
		thicknessTools.getStyleClass().addAll("thicknessTools", "background");
		thicknessTools.getChildren().addAll(thicknessLabel, thicknessSlider, currentThickness);
		this.setVgap(5);
		this.add(thicknessTools, 0, row);
		row ++;
		this.add(colorSelection, 0, row);
		row ++;
		this.add(FillStyleSelectorGrid, 0, row);
	}

	@Override
	public void handle(MouseEvent event) {
		try {
			this.thickness = ((Slider)event.getSource()).getValue();
			currentThickness.setText("Thickness: " + String.valueOf(this.thickness));
		} catch (ClassCastException e) {
			if(event.getSource().getClass().equals(solidButton.getClass()) || event.getSource().getClass().equals(outlineButton.getClass())) {
				
				if(((RadioButton) event.getSource()).equals(solidButton)) {
					this.style = true;
				}else {
					this.style = false;
				}
			} else {
				CustomButton button = ((CustomButton) event.getSource());
				this.currentColor = button.getValue();
			}
		}
	}
	
	public double getThickness () {
		return this.thickness;
	}
	
	public String getCurrentColor() {
		return this.currentColor;
	}
	
	public boolean isSolid() {
		return this.style;
	}
}

