package ca.utoronto.utm.paint;

//import ca.utoronto.utm.ShapeState.State;
import javafx.event.ActionEvent;

import javafx.event.EventHandler;
import javafx.geometry.Pos;
//import javafx.scene.control.Button;
//import javafx.scene.control.Toggle;
import javafx.scene.control.ToggleGroup;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;
import ca.utoronto.utm.Factory.Factory;

public class ShapeChooserPanel extends GridPane implements EventHandler<ActionEvent> {

	private View view; // So we can talk to our parent or other components of the view
	private Factory factory;

	public ShapeChooserPanel(View view) {

		this.view = view;
		
		this.factory = new Factory(this.view);

		this.setAlignment(Pos.TOP_CENTER);
		String[] buttonLabels = { "Circle", "Rectangle", "Square", "Squiggle", "Polyline" };
		ImageView[] images = {new ImageView("circle.png"), new ImageView("rectangle.png"), new ImageView("square.png"), 
				new ImageView("squiggle.png"), new ImageView("polyline.png")};

		int row = 0;
		this.setVgap(10);
		this.setHgap(5);
		this.getStyleClass().add("background");
		ToggleGroup brushes = new ToggleGroup();
		for (int i = 0; i < buttonLabels.length; i++) {
			CustomButton button = new CustomButton(buttonLabels[i], brushes);
			button.getStyleClass().add("shapeChoosers");
			button.setGraphic(images[i]);
			button.setMinWidth(20);
			if (i % 2 == 0) {
				this.add(button, 0, row);
			} else {
				this.add(button, 1, row);
				row++;
			}
			button.setOnAction(this);
		}
		
	}
	
	public View getView() {
		return this.view;
	}

	@Override
	public void handle(ActionEvent event) {
		String shape = ((CustomButton) event.getSource()).getValue();
		this.factory.create(shape);
	}
}
