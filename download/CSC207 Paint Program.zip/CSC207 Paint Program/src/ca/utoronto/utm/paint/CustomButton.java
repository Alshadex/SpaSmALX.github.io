package ca.utoronto.utm.paint;

import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;

public class CustomButton extends ToggleButton{

	private String value;
	
	public CustomButton(String value, ToggleGroup togglegroup) {
		super();
		this.value = value;
		this.setToggleGroup(togglegroup);
	}
	
	public String getValue() {
		return this.value;
	}
}
