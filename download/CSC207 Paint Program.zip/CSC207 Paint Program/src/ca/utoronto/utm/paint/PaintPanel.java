package ca.utoronto.utm.paint;

import javafx.event.EventHandler;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

import java.util.Observable;
import java.util.Observer;



public class PaintPanel extends StackPane implements Observer, EventHandler<MouseEvent> {

	private int i = 0;
	private PaintModel model; // slight departure from MVC, because of the way painting works
	private View view; // So we can talk to our parent or other components of the view
	
	private Canvas canvas;

	public PaintPanel(PaintModel model, View view) {

		this.canvas = new Canvas(1000, 900);
		this.getChildren().add(this.canvas);
		// The canvas is transparent, so the background color of the
		// containing pane serves as the background color of the canvas.
		this.getStyleClass().add("panel");

		this.addEventHandler(MouseEvent.ANY, this);

		this.model = model;
		
		this.model.addObserver(this);
		
		this.view = view;
	}

	public void repaint() {

		GraphicsContext g = this.canvas.getGraphicsContext2D();

		// Clear the canvas
		g.clearRect(0, 0, this.getWidth(), this.getHeight());
		this.model.execute(g);
	}

	@Override
	public void update(Observable o, Object arg) {

		// Not exactly how MVC works, but similar.
		this.repaint();
	}

	@Override
	public void handle(MouseEvent event) {

		if (event.getEventType() == MouseEvent.MOUSE_DRAGGED) {
			this.view.getStrategy().mouseDragged(event);
		} else if (event.getEventType() == MouseEvent.MOUSE_PRESSED) {
			this.view.getStrategy().mousePressed(event);
		} else if (event.getEventType() == MouseEvent.MOUSE_RELEASED) {
			this.view.getStrategy().mouseReleased(event);
		} else if (event.getEventType() == MouseEvent.MOUSE_CLICKED) {
			this.view.getStrategy().mouseClicked(event);
		}
	}
	
	public PaintModel getPaintModel() {
		return this.model;
	}
	
	public GraphicsContext getGraphicsContext() {
		return this.canvas.getGraphicsContext2D();
	}
}
