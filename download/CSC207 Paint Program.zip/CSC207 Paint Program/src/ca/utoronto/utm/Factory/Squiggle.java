package ca.utoronto.utm.Factory;

import java.util.ArrayList;


/**
 * Class for single Squiggle shape. Holds ArrayList of Points.
 * 
 * @author geniusName group
 */
public class Squiggle {
	
	/**
	 * ArrayList of Points to strokeLine between.
	 */
	private ArrayList<Point> points;
	
	
	/**
	 * Default constructor. Instantiates new ArrayList<Point>.
	 */
	public Squiggle() {
		this.points = new ArrayList<Point>();;
	}
	
	
	/**
	 * Squiggle constructor taking a Squiggle object instance. Makes Copy.
	 * @param squiggle (Squiggle)
	 */
	public Squiggle(Squiggle squiggle) {
		this.points = squiggle.getSquiggle();
	}
	
	
	/**
	 * Adds Point to ArrayList.
	 * @param nextPoint (Point)
	 */
	public void addPoint(Point nextPoint) {
		this.points.add(nextPoint);
	}
	
	
	/**
	 * Returns ArrayList of Points.
	 * @return ArrayList (ArrayList<Point>)
	 */
	public ArrayList<Point> getSquiggle(){
		return this.points;
	}

}
