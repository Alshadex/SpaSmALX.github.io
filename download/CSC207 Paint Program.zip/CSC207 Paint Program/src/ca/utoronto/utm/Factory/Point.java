package ca.utoronto.utm.Factory;


/**
 * Point class. Knows x and y coordinates. Used by other shapes.
 * 
 * @author geniusName group
 */
public class Point{
	int x, y; // x and y coordinates
	
	/**
	 * Construct the point with x and y coordinates, thickness and color
	 * 
	 * @param x (int)
	 * @param y (int)
	 */
	public Point(int x, int y) {
		this.x = x;
		this.y = y;
	}
	
	/**
	 * Construct the point from the given point. Makes copy.
	 * 
	 * @param point (Point)
	 */
	public Point(Point point) {
		this.x = point.getX();
		this.y = point.getY();
	}
	
	/**
	 * Return the x coordinate of the point
	 * 
	 * @return x (int)
	 */
	public int getX() {
		return x;
	}
	
	/**
	 * Set the x coordinate of the point
	 * 
	 * @param x (int)
	 */
	public void setX(int x) {
		this.x = x;
	}
	
	/**
	 * Return the y coordinate of the point
	 * 
	 * @return y (int)
	 */
	public int getY() {
		return y;
	}
	
	/**
	 * Set the y coordinate of the point
	 * 
	 * @param y (int)
	 */
	public void setY(int y) {
		this.y = y;
	}
}
