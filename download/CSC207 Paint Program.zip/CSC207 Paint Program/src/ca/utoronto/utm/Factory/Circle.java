package ca.utoronto.utm.Factory;

import javafx.scene.canvas.GraphicsContext;
/**
 * Circle class which knows it's centre point, radius.
 * 
 * @author geniusName group
 *
 */
public class Circle{
	
	private Point centre; // Any point with given x and y
	private int radius; // 0 <= radius
	
	/**
	 *  Constructs empty Circle. This is used by Factory.java when the user selects circle mode.
	 */
	public Circle() {
		this.centre = null;
		this.radius = 0;
	}
	
	
	/**
	 * Construct balloon with the specified centre, radius, thickness, color and style.
	 * 
	 * @param centre (Point)
	 * @param radius (int)
	 */
	public Circle(Point centre, int radius) {
		this.centre = centre;
		this.radius = radius;
	}
	
	
	/**
	 * Construct the circle from the given circle
	 * 
	 * @param circle (Circle)
	 */
	public Circle(Circle circle) {
		this.centre = circle.getCentre();
		this.radius = circle.getRadius();
	}
	
	
	/**
	 * Returns the centre of the circle
	 * 
	 * @return Centre (Point)
	 */
	public Point getCentre() {
		return centre;
	}
	
	
	/**
	 * Set the centre of the circle
	 * 
	 * @param centre (Point)
	 */
	public void setCentre(Point centre) {
		this.centre = centre;
	}
	
	
	/**
	 * Return radius of the circle
	 * 
	 * @return Radius (int)
	 */
	public int getRadius() {
		return radius;
	}
	
	
	/**
	 * Set the radius of the circle
	 * 
	 * @param radius (int)
	 */
	public void setRadius(int radius) {
		this.radius = radius;
	}

}
