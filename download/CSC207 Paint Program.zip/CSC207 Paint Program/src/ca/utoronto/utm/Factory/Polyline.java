package ca.utoronto.utm.Factory;

import java.util.ArrayList;


/**
 * Class for a single Polyline shape. Holds ArrayList of Points.
 * 
 * @author geniusName group
 */
public class Polyline {
	
	/**
	 *  ArrayList holds all points to be connected using StrokeLine.
	 */
	private ArrayList<Point> points;
	
	
	/**
	 * Polyline constructor. Instantiates new ArrayList of Points.
	 */
	public Polyline() {
		this.points = new ArrayList<Point>();
	}
	
	
	/**
	 * Constructor taking a Polyline instance and copies its ArrayList.
	 * @param polyline (Polyline)
	 */
	public Polyline(Polyline polyline) {
		this.points = polyline.getPolyline();
	}
	
	
	/**
	 * Adds new Point object into ArrayList.
	 * @param nextPoint (Point)
	 */
	public void addPoint(Point nextPoint) {
		this.points.add(nextPoint);
	}
	
	
	/**
	 * Gets ArrayList of points for Polyline object.
	 * @return ArrayList<Point>
	 */
	public ArrayList<Point> getPolyline(){
		return this.points;
	}
	
	
	/**
	 * Deletes last Point in ArrayList.
	 */
	public void deleteLast() {
		this.points.remove(this.points.size() - 1);
	}

}
