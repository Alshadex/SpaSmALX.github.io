package ca.utoronto.utm.Factory;


/**
 * Rectangle class represents the rectangle. Has starting point from where the rectangle is drawn, 
 * it's width, height.
 * 
 * @author geniusName group
 */
public class Rectangle {
	private Point startingPoint; // Starting point of the rectangle
	private int width; // Width of the rectangle
	private int height; // Height of the rectangle
	
	
	/**
	 * Rectangle default constructor.
	 */
	public Rectangle() {
		this.startingPoint = null;
		this.width = 0;
		this.height = 0;
	}
	
	/**
	 * Construct rectangle with the given starting point, width, height, thickness, color and style
	 * 
	 * @param startingPoint (Point)
	 * @param width (int)
	 * @param height (int)
	 */
	public Rectangle(Point startingPoint, int width, int height) {
		this.startingPoint = startingPoint;
		this.width = width;
		this.height = height;
	}
	
	/**
	 * Construct the rectangle from the given rectangle. Makes copy.
	 * 
	 * @param rectangle (Rectangle)
	 */
	public Rectangle(Rectangle rectangle) {
		this.startingPoint = rectangle.getStartingPoint();
		this.width = rectangle.getWidth();
		this.height = rectangle.getHeight();
	}
	
	
	/**
	 * Return the starting point of the rectangle
	 * 
	 * @return Starting (Point)
	 */
	public Point getStartingPoint() {
		return startingPoint;
	}
	
	/**
	 * Set the starting point of the rectangle
	 * 
	 * @param startingPoint (Point)
	 */
	public void setStartingPoint(Point startingPoint) {
		this.startingPoint = startingPoint;
	}
	
	/**
	 * Return width of the rectangle
	 * 
	 * @return Width (int)
	 */
	public int getWidth() {
		return this.width;
	}
	
	/**
	 * Return height of the rectangle
	 * 
	 * @return Height (int)
	 */
	public int getHeight() {
		return this.height;
	}
	
	/**
	 * Set height of the rectangle
	 * 
	 * @param height (int)
	 */
	public void setHeight(int height) {
		this.height = height;
	}
	
	/**
	 * Set width of the rectangle
	 * 
	 * @param width (int)
	 */
	public void setWidth(int width) {
		this.width = width;
	}
}
