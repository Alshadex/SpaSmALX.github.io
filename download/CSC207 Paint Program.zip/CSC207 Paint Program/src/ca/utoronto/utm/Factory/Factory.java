package ca.utoronto.utm.Factory;

import ShapeManipulators.CircleStrategy;
import ShapeManipulators.PolylineStrategy;
import ShapeManipulators.RectangleStrategy;
import ShapeManipulators.SquareStrategy;
import ShapeManipulators.SquiggleStrategy;
import ca.utoronto.utm.drawableShapes.DrawableCircle;
import ca.utoronto.utm.drawableShapes.DrawablePolyline;
import ca.utoronto.utm.drawableShapes.DrawableRectangle;
import ca.utoronto.utm.drawableShapes.DrawableSquiggle;
import ca.utoronto.utm.paint.View;

/**
 * Factory Design Pattern class. Receives request from ShapeChooserPanel to produce a specific shape.
 * 
 * @author geniusName group
 */
public class Factory {
	
	private View view;
	
	
	/**
	 * Constructor passing a view reference. View is used to add shape instances into the command
	 * design pattern ArrayList.
	 * 
	 * @param view (View)
	 */
	public Factory(View view) {
		this.view = view;
	}
	
	
	/**
	 * Instantiates specific drawableShape with the shape object and the current shape modifiers.
	 * @param shapeName (String)
	 */
	public void create(String shapeName) {
		if ((!this.view.getPaintModel().getCommands().isEmpty()) && this.view.getPaintModel().getLastCommand().isEmpty()) {
			this.view.getPaintModel().getCommands().remove(this.view.getPaintModel().getCommands().size() - 1);
		}
		switch (shapeName) {
		case "Circle": 
			this.view.getPaintModel().addCommand(new DrawableCircle(new Circle(), new ShapeModifiers()), 
									this.view.getPaintPanel().getGraphicsContext());
				this.view.setStrategy(new CircleStrategy(this.view));
		break;
		
		case "Rectangle": this.view.getPaintModel().addCommand(new DrawableRectangle(new Rectangle(), new ShapeModifiers()),
									this.view.getPaintPanel().getGraphicsContext());
				this.view.setStrategy(new RectangleStrategy(this.view));
		break;
		
		case "Squiggle": this.view.getPaintModel().addCommand(new DrawableSquiggle(new Squiggle(), new ShapeModifiers()),
									this.view.getPaintPanel().getGraphicsContext());
				this.view.setStrategy(new SquiggleStrategy(this.view));
		break;
		
		case "Polyline": this.view.getPaintModel().addCommand(new DrawablePolyline(new Polyline(), new ShapeModifiers()),
									this.view.getPaintPanel().getGraphicsContext());
				this.view.setStrategy(new PolylineStrategy(this.view));
		break;
		
		case "Square": this.view.getPaintModel().addCommand(new DrawableRectangle(new Square(), new ShapeModifiers()),
									this.view.getPaintPanel().getGraphicsContext());
				this.view.setStrategy(new SquareStrategy(this.view));
		break;
		}
		
	}
	
}
