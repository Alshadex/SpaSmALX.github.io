package ca.utoronto.utm.Factory;


/**
 * Class for single square shape. Square inherits from rectangle.
 * 
 * @author geniusName group
 */
public class Square extends Rectangle {
	
	private int length;
	
	
	/**
	 * Default constructor. Sets length of square to 0.
	 */
	public Square() {
		this.length = 0;
	}
	
	
	/**
	 * Constructor to set a Point for the square and its length.
	 * @param startingPoint (Point)
	 * @param length (int)
	 */
	public Square(Point startingPoint, int length) {
		this.length = length;
	}
	
	
	/**
	 * Constructor to take an existing Square instance. Makes copy.
	 * @param square
	 */
	public Square(Square square) {
		super(square.getStartingPoint(), square.getLength(), square.getLength());
		this.length = square.getLength();
	}
	
	
	/**
	 * Sets the length of the square.
	 * @param length (int)
	 */
	public void setLength(int length) {
		this.length = length;
	}
	
	
	/**
	 * Returns length of the square.
	 * @return length (int)
	 */
	public int getLength() {
		return this.length;
	}
}
