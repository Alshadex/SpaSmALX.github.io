package ca.utoronto.utm.Factory;

import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;


/**
 * Class for storing and changing Shape attributes. Line thickness, color and fill-style.
 * 
 * @author geniusName group
 */
public class ShapeModifiers {
	
	private double thickness;
	private String color;
	private boolean solid;
	
	
	/**
	 * ShapeModifiers default constructor.
	 */
	public ShapeModifiers() {
		this.thickness = 1.0;
		this.color = "WHITE";
		this.solid = false;
	}
	
	
	/**
	 * ShapeModifiers constructor with specific line thickness, color and fill-style arguements.
	 * @param thickness (double)
	 * @param color (String)
	 * @param solid (boolean)
	 */
	public ShapeModifiers(double thickness, String color, boolean solid) {
		this.thickness = thickness;
		this.color = color;
		this.solid = solid;
	}
	
	
	/**
	 * ShapeModifiers construcor using a different ShapeModifiers instance. Makes copy.
	 * @param style (ShapeModifiers)
	 */
	public ShapeModifiers(ShapeModifiers style) {
		this.thickness = style.thickness;
		this.color = style.color;
		this.solid = style.solid;
	}
	
	
	/**
	 * Returns thickness of line. Each instance of ShapeModifiers applies to a different shape object.
	 * @return thickness (double)
	 */
	public double getThickness() {
		return this.thickness;
	}
	
	
	/**
	 * Sets the line thickness.
	 * @param thickness (double)
	 */
	public void setThickness(double thickness) {
		this.thickness = thickness;
	}
	
	
	/**
	 * Returns current color in RGB form.
	 * @return color (Paint)
	 */
	public Paint getColor() {
		return Color.web(color);
	}
	
	
	/**
	 * Returns current color in String form.
	 * @return color (String)
	 */
	public String getStringColor() {
		return this.color;
	}
	
	
	/**
	 * Sets a new color.
	 * @param color (String)
	 */
	public void setColor(String color) {
		this.color = color;
	}
	
	
	/**
	 * Returns boolean state of fill-style modifier. isSolid true means object is solid fill-style.
	 * @return isSolid (boolean)
	 */
	public boolean isSolid() {
		return this.solid;
	}
	
	/**
	 * Sets isSolid boolean variable.
	 * @param isSolid (boolean)
	 */
	public void setSolid(boolean isSolid) {
		this.solid = isSolid;
	}
}
