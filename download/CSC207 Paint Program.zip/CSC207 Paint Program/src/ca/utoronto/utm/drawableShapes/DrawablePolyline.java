package ca.utoronto.utm.drawableShapes;

import ca.utoronto.utm.Factory.Polyline;
import ca.utoronto.utm.Factory.ShapeModifiers;
import javafx.scene.canvas.GraphicsContext;
/**
 * 
 * This class implements the DrawingCommand interface, that would know how to 
 * draw the given polyline with the given style. This is part of Command Design
 * Pattern
 * 
 * The following class will have polyline, which it needs to draw, and the style, 
 * with which polyline has to be drawn
 * 
 * @author GeniusName group
 *
 */
public class DrawablePolyline extends Polyline implements DrawingCommand{
	
	private ShapeModifiers style; // the style, which contains thickness, color and whether it is solid or not.
	
	/**
	 * Constructor of new Drawable Polyline
	 * 
	 * @param polyline Polyline we want to draw
	 * @param style Style of how we want to draw the polyline
	 */
	public DrawablePolyline (Polyline polyline, ShapeModifiers style) {
		super(polyline);
		this.style = style;
		
	}
	
	/**
	 * Return the style of the polyline
	 * 
	 * @return Style of the polyline
	 */
	public ShapeModifiers getStyle() {
		return this.style;
	}
	
	/**
	 * Draw the polyline
	 */
	@Override
	public void execute(GraphicsContext g) {
		for(int i = 0; i < this.getPolyline().size()-1; i++) {
			g.setLineWidth(this.style.getThickness());
			g.setStroke(this.getStyle().getColor());
			g.strokeLine(this.getPolyline().get(i).getX(), this.getPolyline().get(i).getY(), this.getPolyline().get(i+1).getX(), 
					this.getPolyline().get(i+1).getY());
		}
	}
	
	/**
	 * Check whether the polyline has to be drawn
	 */
	public boolean isEmpty() {
		return this.getPolyline().isEmpty();
	}

}
