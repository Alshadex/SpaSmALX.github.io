package ca.utoronto.utm.drawableShapes;

import ca.utoronto.utm.Factory.Squiggle;
import ca.utoronto.utm.Factory.ShapeModifiers;
import javafx.scene.canvas.GraphicsContext;

/**
 * 
 * This class implements the DrawingCommand interface, that would know how to 
 * draw the given squiggle with the given style. This is part of Command Design
 * Pattern
 * 
 * The following class will have squiggle, which it needs to draw, and the style, 
 * with which squiggle has to be drawn
 * 
 * @author GeniusName group
 *
 */
public class DrawableSquiggle extends Squiggle implements DrawingCommand{
	
	private ShapeModifiers style; // the style, which contains thickness, color and whether it is solid or not.
	
	/**
	 * Constructor of new Drawable Squiggle
	 * 
	 * @param squiggle Squiggle we want to draw
	 * @param style Style of how we want to draw the Squiggle
	 */
	public DrawableSquiggle(Squiggle squiggle, ShapeModifiers style) {
		super(squiggle);
		this.style = new ShapeModifiers(style);
	}
	
	/**
	 * Return the style of the squiggle
	 * 
	 * @return Style of the squiggle
	 */
	public ShapeModifiers getStyle() {
		return this.style;
	}
	
	/**
	 * Draw squiggle
	 */
	@Override
	public void execute(GraphicsContext g) {
		g.setLineWidth(this.getStyle().getThickness());
		g.setStroke(this.getStyle().getColor());
		for(int i = 0; i < this.getSquiggle().size()-1; i++) {
			g.strokeLine(this.getSquiggle().get(i).getX(), this.getSquiggle().get(i).getY(), this.getSquiggle().get(i+1).getX(), 
					this.getSquiggle().get(i+1).getY());
		}
	}
	/**
	 * Check whether the squiggle has to be drawn
	 */
	public boolean isEmpty() {
		return this.getSquiggle().isEmpty();
	}

}
