package ca.utoronto.utm.drawableShapes;

import ca.utoronto.utm.Factory.Circle;
import ca.utoronto.utm.Factory.ShapeModifiers;
import javafx.scene.canvas.GraphicsContext;

/**
 * This class implements the DrawingCommand interface, that would know how to 
 * draw the given circle with the given style. This is part of Command Design
 * Pattern
 * 
 * The following class will have circle, which it needs to draw, and the style, 
 * with which the circle has to be drawn
 * 
 * @author GeniusName group
 */

public class DrawableCircle extends Circle implements DrawingCommand {
	
	private ShapeModifiers style; // the style, which contains thickness, color and whether it is solid or not.
	
	/**
	 * Constructor of new Drawable Cirlce
	 * 
	 * @param circle Circle we want to draw
	 * @param style Style of how we want to draw the circle
	 */
	public DrawableCircle(Circle circle, ShapeModifiers style) {
		super(circle); // Construct the given circle
		this.style = new ShapeModifiers(style);
	}
	
	/**
	 * Return the style of the drawable circle
	 * 
	 * @return style of the drawable Circle
	 */
	public ShapeModifiers getStyle() {
		return this.style;
	}
	
	/**
	 * Draw the circle
	 */
	public void execute(GraphicsContext g) {
		int x = this.getCentre().getX();
		int y = this.getCentre().getY();
		int radius = this.getRadius();
		g.setLineWidth(this.style.getThickness());
		g.setStroke(this.style.getColor());
		g.strokeOval(x - radius, y - radius, 2*radius, 2*radius);
		if (this.style.isSolid()) {
			g.setFill(this.style.getColor());
			g.fillOval(x-radius, y-radius, 2*radius, 2*radius);
		}
	}
	
	/**
	 * Check whether the circle has to be drawn
	 */
	public boolean isEmpty() {
		if(this.getCentre() == null) {
			return true;
		}
		else {
			return false;
		}
	}
	

}
