package ca.utoronto.utm.drawableShapes;

import javafx.scene.canvas.GraphicsContext;

/**
 * Interface of Command, which contains only one method stub execute()
 * Used to create a different types of commands for Command Design Pattern
 * 
 * @author geniusName group
 */
public interface DrawingCommand {
	
	/**
	 * Method of execution, which specifies what is needed to be executed
	 */
	public void execute(GraphicsContext g);
	public boolean isEmpty();
	
}
