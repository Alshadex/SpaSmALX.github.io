package ca.utoronto.utm.drawableShapes;

import ca.utoronto.utm.Factory.Rectangle;
import ca.utoronto.utm.Factory.ShapeModifiers;
import javafx.scene.canvas.GraphicsContext;

/**
 * This class implements the DrawingCommand interface, that would know how to 
 * draw the given rectangle with the given style. This is part of Command Design
 * Pattern
 * 
 * The following class will have rectangle, which it needs to draw, and the style, 
 * with which the rectangle has to be drawn
 * 
 * @author GeniusName group
 */
public class DrawableRectangle extends Rectangle implements DrawingCommand {
	
	private ShapeModifiers style; // the style, which contains thickness, color and whether it is solid or not.
	
	/**
	 * Constructor of new Drawable Rectangle
	 * 
	 * @param rectangle Rectangle we want to draw
	 * @param style Style of how we want to draw the Rectangle
	 */
	public DrawableRectangle(Rectangle rectangle, ShapeModifiers style) {
		super(rectangle);
		this.style = new ShapeModifiers(style);
	}
	
	/**
	 * Return the style of the drawable Rectangle
	 * 
	 * @return style of the drawable Rectangle
	 */
	public ShapeModifiers getStyle() {
		return this.style;
	}
	
	/**
	 * Draw the rectangle
	 */
	@Override
	public void execute(GraphicsContext g) {
		g.setLineWidth(this.style.getThickness());
		int x = this.getStartingPoint().getX();
		int y = this.getStartingPoint().getY();
		int width = this.getWidth();
		int height = this.getHeight();
		if (this.style.isSolid()) {
			g.setFill(this.style.getColor());
			if (width < 0 && height < 0) {
				g.fillRect(x+width, y+height, Math.abs(width), Math.abs(height));
			} else if (width < 0 && height > 0) {
				g.fillRect(x+width, y, Math.abs(width), height);
			} else if (width > 0 && height < 0) {
				g.fillRect(x, y+height, width, Math.abs(height));
			} else {
				g.fillRect(x,y,width,height);
			}
		} else {
			g.setStroke(this.style.getColor());
			g.strokeLine(x, y, x, y + height);
			g.strokeLine(x, y, x + width, y);
			g.strokeLine(x, y + height, x + width, y + height);
			g.strokeLine(x + width, y, x + width, y + height);
		}
	}
	/**
	 * Check whether the rectangle has to be drawn
	 */
	public boolean isEmpty() {
		if(this.getStartingPoint() == null) {
			return true;
		}
		else {
			return false;
		}
	}
	
}
